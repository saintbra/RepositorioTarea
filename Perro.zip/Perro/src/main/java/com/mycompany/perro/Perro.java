/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.perro;

/**
 *
 * @author brando
 */
public class Perro {
    String nombre;
    int edad;
    
    public Perro(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
    
    public void saltar (){
        System.out.println(this.nombre + " empezo a saltar ");
    }
    
    public void jugar (){
        System.out.println(this.nombre + " empezo a ladrar ");
    }
    
    public void comer (){
        System.out.println(this.nombre + " empezo a correr ");
    }
}