/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package empleado;

/**
 *
 * @author brando
 */
import java.util.Scanner;

abstract class Animal {
    String nombre;
    String apellido;
    private int edad;

    public Animal(String nombre, String apellido, int edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }

    public String obtenerNombre() {
        return nombre;
    }

    public String obtenerApellido() {
        return apellido;
    }

    public int obtenerEdad() {
        return edad;
    }

    public abstract String hacerSonido();

    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre + " " + apellido);
        System.out.println("Edad: " + edad + " años");
    }
}

class Perro extends Animal {
    private String raza;

    public Perro(String nombre, String apellido, int edad, String raza) {
        super(nombre, apellido, edad);
        this.raza = raza;
    }

    @Override
    public String hacerSonido() {
        return "Guau guau";
    }

    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Raza: " + raza);
    }
}

class Gato extends Animal {
    private String pelaje;

    public Gato(String nombre, String apellido, int edad, String pelaje) {
        super(nombre, apellido, edad);
        this.pelaje = pelaje;
    }

    @Override
    public String hacerSonido() {
        return "Miau miau";
    }

    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Pelaje: " + pelaje);
    }
}

public class Animals {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el nombre del perro:");
        String perroN = scanner.nextLine();
        System.out.println("Ingrese el apellido del perro:");
        String perroP = scanner.nextLine();
        System.out.println("Ingrese la raza del perro:");
        
        String razaDelP = scanner.nextLine();
        int edadP = obtenerEdadValida(scanner);


        Perro perro = new Perro(perroN, perroP, edadP, razaDelP);

        System.out.println("\nIngrese el nombre y apodo del gato:");
        
        String nombreG = scanner.nextLine();
        System.out.println("\nIngrese el nombre y apodo del gato:");
        String nombreR = scanner.nextLine();
        
        System.out.println("Ingrese el pelaje del gato:");
        
        String pelajeDelGato = scanner.nextLine();
        int edadG = obtenerEdadValida(scanner);
       
        Gato gato = new Gato(nombreG, nombreR, edadG, pelajeDelGato);

        System.out.println("\nInformacion del perro:");
        perro.mostrarInformacion();
        System.out.println("Sonido: " + perro.hacerSonido());

        System.out.println("\nInformacion del gato:");
        gato.mostrarInformacion();
        System.out.println("Sonido: " + gato.hacerSonido());
    }

private static int obtenerEdadValida(Scanner scanner) {
    while (true) {
        try {
            System.out.println("Ingrese la edad: ");
            int edad = scanner.nextInt();

            if (edad < 0) {
                System.out.println("\nEdad no valida. Debe ser un numero positivo");
            } else {
                return edad;
            }
        } catch (Exception e) {
            System.out.println("Error: Ingrese un numero entero valido");
            scanner.next();  // Limpiar el buffer del scanner para evitar un bucle infinito
        }
    }
}
}
